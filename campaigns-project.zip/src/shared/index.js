import AppArea from "./layouts/AppArea";

export {
    AppArea
}
