import getAppDb from "./appDb/getAppDb";
import getFirebaseApp from "./firebaseApp/getFirebaseApp";

export {
    getFirebaseApp,
    getAppDb
}
