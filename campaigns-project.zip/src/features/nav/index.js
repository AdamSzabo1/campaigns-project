import SiteFooter from "./SiteFooter/SiteFooter";
import SiteHeader from "./SiteHeader/SiteHeader";

export {
    SiteHeader,
    SiteFooter
}
