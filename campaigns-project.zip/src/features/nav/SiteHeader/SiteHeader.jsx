import Navbar from "../Navbar/Navbar";

const SiteHeader = () => {

    return (
        <header>
            <Navbar />
        </header>
    );
}

export default SiteHeader;
