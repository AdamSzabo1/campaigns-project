
const SiteFooter = () => {

    return (
        <footer className="bg-dark text-white">
            <div className="container p-2" >
                All rights reserved
            </div>
        </footer>
    );
}

export default SiteFooter;
